# Experimental protocol

## Objective

Evaluate the worst-case expected terminal objective error for convex, 1-smooth functions with an attained minimum and initial distance at most one. The function is fixed before the random order is drawn. All trajectories share one set of smooth-convex interpolation constraints; common prefixes share oracle nodes.

## Two-step experiments

Compare the optimal randomized design, a rational separation example, fair mixing, both fixed orders, and the optimal deterministic two-step design. Also optimize the order probability at the fixed deterministic pair. Compute a probability curve, a 21-by-21 stepsize grid with probability optimization, and 81-point coordinate slices. Retain every scalar-search evaluation and solver diagnostic. Independently assemble primal checks for the baseline configurations and grid minimum.

## Common objectives

Evaluate upper-clipped, lower-clipped, and Huber objectives using exact rational arithmetic at stepsizes (7/5, 19/10), with forward probability 2/3. Evaluate both orders on each same function. Finite witness maxima are lower bounds on full-class risk. Separately maximizing each branch allows an order-aware objective and gives a different quantity.

## Composition

At horizons 2, 4, and 5, enumerate all random outcomes and solve joint-tree primal and dual PEPs using Clarabel, with SCS crosschecks for random schedules. Compare against the analytic formula and a common Huber witness. The deterministic comparator uses the same composition rule and the optimal deterministic history seed.

At horizons 11, 23, 47, 95, 191, 383, and 767, compare analytic formulas with Huber evaluations and schedule checks. These are explicit-witness checks, not full PEP solves. Schedule checks use the fixed seed in `code/schedules.py`.

## Data and diagnostics

CSV files retain evaluations, statuses, residuals, and crosschecks, including inaccurate statuses. JSON files contain summaries and exact witness traces. NPZ files contain numerical primal/dual solutions and interpolation arrays and can be loaded with `numpy.load(..., allow_pickle=False)`. `environment.json` records the supplied data's software versions.

A residual threshold of 1e-6 is used for numerical resolution; see the code for componentwise diagnostics and solver settings. Floating-point PEP values are numerical checks of the theoretical claims, not exact certificates. The local parameter grid does not establish global optimality or uniqueness.
