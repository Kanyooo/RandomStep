"""Recompute experiments or redraw figures from the included numerical data."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--figures-only', action='store_true', help='Use the supplied data without rerunning SDP solvers.')
    args = parser.parse_args()
    env = os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', OMP_NUM_THREADS='1', MPLBACKEND='Agg')
    jobs = []
    if not args.figures_only:
        for name in ['two_step_claims', 'common_witnesses', 'composition_claims']:
            jobs.append([f'code/{name}.py', '--output-dir', 'results'])
    data = 'data' if args.figures_only else 'results'
    jobs.append(['code/make_figures.py', '--data-dir', data, '--output-dir', 'figures'])
    for job in jobs:
        print(f'Running {Path(job[0]).stem}', flush=True)
        subprocess.run([sys.executable, *job], cwd=ROOT, env=env, check=True)
    print('Completed. Figures: figures/. Included data remain in data/.')


if __name__ == '__main__':
    main()
