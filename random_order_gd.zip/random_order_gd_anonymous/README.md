# Randomizing stepsize order in gradient descent

Experimental code and numerical data for two-step random-order gradient descent and composed schedules.

Use Python 3.12. Install dependencies and redraw the figures from the included data:

```sh
python -m pip install -r requirements.txt
python run_all.py --figures-only
```

To recompute all experiments, including the parameter grid, independent primal/dual checks, and SCS crosschecks:

```sh
python run_all.py
```

- `code/`: PEP models, schedules, exact witness evaluations, and plotting.
- `data/`: supplied numerical evaluations, solver diagnostics, summaries, and solution arrays. These are generated experimental data, not an external dataset.
- `PROTOCOL.md`: experiment definitions and numerical checks.

New computations are written to `results/`; plots are written to `figures/`. The supplied data are not overwritten. Computation uses CPU and the open-source Clarabel and SCS solvers; no GPU, external dataset, or solver license is needed. Floating-point results and solver statuses can vary across platforms.
