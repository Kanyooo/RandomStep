# Third-party dependencies

The Python packages listed in `requirements.txt` are installed separately. Each retains its own license and notices, available in its installed distribution. No third-party library source or external dataset is bundled.
