"""Numerical common-function PEP experiment for two reversed GD steps.

Run from anywhere: python pep_experiment.py [--output-dir PATH]
All results are floating-point SDP solutions, not exact proof certificates.
Dependencies: numpy, scipy, cvxpy, clarabel, scs.
"""
from __future__ import annotations

import argparse
import csv
import json
import platform
import time
import warnings
from pathlib import Path

import cvxpy as cp
import numpy as np
from scipy.optimize import brentq

A_STAR = 1.39914812843717023214
B_STAR = 1.90722760716161662160
P_STAR = 0.66349447395849179421
TAU_STAR = 0.06568141550097899620
A_DET = np.sqrt(2.0)
B_DET = (3.0 + np.sqrt(9.0 + 8.0 * np.sqrt(2.0))) / 4.0
R_DET = 1.0 / (2.0 * (1.0 + 2.0 * (A_DET + B_DET)))


class JointTrajectoryPEP:
    """Six nodes, five function values, six-dimensional Gram matrix.

    Nodes: [optimum, initial, first+, terminal+, first-, terminal-].
    Gram basis: [x0, g0, g1+, g2+, g1-, g2-].
    Include all 30 directed interpolation inequalities across both branches.
    """

    def __init__(self):
        self.pairs = [(i, j) for i in range(6) for j in range(6) if i != j]
        self.D = np.zeros((30, 5))
        for k, (i, j) in enumerate(self.pairs):
            if i:
                self.D[k, i - 1] += 1
            if j:
                self.D[k, j - 1] -= 1
        self.G = cp.Variable((6, 6), symmetric=True)
        self.F = cp.Variable(5)
        self.Mflat = cp.Parameter((30, 36))
        self.c = cp.Parameter(5)
        self.constraints = [
            self.G >> 0,
            self.G[0, 0] <= 1,
            self.D @ self.F - self.Mflat @ cp.vec(self.G, order="C") >= 0,
        ]
        self.problem = cp.Problem(cp.Maximize(self.c @ self.F), self.constraints)
        # An independently assembled explicit dual avoids relying solely on
        # the primal solver's returned Lagrange multipliers.
        self.dual_lambda = cp.Variable(30, nonneg=True)
        self.dual_tau = cp.Variable(nonneg=True)
        E00 = np.zeros((6, 6)); E00[0, 0] = 1
        self.dual_Z = self.dual_tau * E00 + cp.reshape(
            self.Mflat.T @ self.dual_lambda, (6, 6), order="C")
        self.dual_problem = cp.Problem(cp.Minimize(self.dual_tau), [
            self.D.T @ self.dual_lambda == -self.c, self.dual_Z >> 0])
        self.last = None

    def matrices(self, a, b):
        E = np.eye(6)
        zero = np.zeros(6)
        gradients = [zero, E[1], E[2], E[3], E[4], E[5]]
        points = [zero, E[0], E[0] - a * E[1],
                  E[0] - a * E[1] - b * E[2], E[0] - b * E[1],
                  E[0] - b * E[1] - a * E[4]]
        matrices = []
        for i, j in self.pairs:
            u = points[i] - points[j]
            v = gradients[i] - gradients[j]
            matrices.append(0.5 * (np.outer(gradients[j], u)
                                     + np.outer(u, gradients[j])
                                     + np.outer(v, v)))
        return np.asarray(matrices)

    def solve(self, a, b, p, solver="CLARABEL", tag="", tolerance=1e-10):
        matrices = self.matrices(a, b)
        self.Mflat.value = matrices.reshape(30, 36)
        self.c.value = np.array([0.0, 0.0, p, 0.0, 1.0 - p])
        options = ({"tol_gap_abs": tolerance, "tol_gap_rel": tolerance,
                    "tol_feas": tolerance, "max_iter": 300}
                   if solver == "CLARABEL" else
                   {"eps_abs": 2e-8, "eps_rel": 2e-8, "max_iters": 250000})
        begin = time.perf_counter()
        with warnings.catch_warnings(record=True) as warning_list:
            warnings.simplefilter("always")
            try:
                value = self.problem.solve(solver=solver, warm_start=False, **options)
                exception = ""
            except Exception as exc:
                value, exception = np.nan, repr(exc)
        result = {
            "tag": tag, "a": float(a), "b": float(b), "p": float(p),
            "solver": solver, "status": self.problem.status,
            "requested_tolerance": tolerance if solver == "CLARABEL" else 2e-8,
            "objective": float(value) if value is not None else np.nan,
            "wall_time_s": time.perf_counter() - begin,
            "exception": exception,
            "warnings": " | ".join(str(w.message) for w in warning_list),
        }
        if self.G.value is None or exception:
            self.last = None
            return result
        G = np.asarray(self.G.value)
        F = np.asarray(self.F.value)
        lam = np.asarray(self.constraints[2].dual_value)
        normdual = float(self.constraints[1].dual_value)
        Z_solver = np.asarray(self.constraints[0].dual_value)
        E00 = np.zeros((6, 6)); E00[0, 0] = 1
        Z = normdual * E00 + np.einsum("k,kij->ij", lam, matrices)
        interpolation = self.D @ F - np.einsum("kij,ij->k", matrices, G)
        result.update({
            "dual_objective": normdual,
            "primal_dual_gap": normdual - float(value),
            "interpolation_min": float(np.min(interpolation)),
            "interpolation_violation": float(max(0, -np.min(interpolation))),
            "gram_min_eigenvalue": float(np.linalg.eigvalsh(G)[0]),
            "normalization_violation": float(max(0, G[0, 0] - 1)),
            "multiplier_min": float(np.min(lam)),
            "dual_slack_min_eigenvalue": float(np.linalg.eigvalsh(Z)[0]),
            "dual_flow_residual_inf": float(np.max(np.abs(self.D.T @ lam + self.c.value))),
            "dual_slack_residual_inf": float(np.max(np.abs(Z - Z_solver))),
            "interpolation_complementarity": float(np.dot(lam, interpolation)),
            "psd_complementarity": float(np.sum(Z * G)),
            "iterations": self.problem.solver_stats.num_iters,
            "solver_time_s": self.problem.solver_stats.solve_time,
        })
        self.last = {"G": G, "F": F, "multipliers": lam, "Z": Z,
                     "M": matrices, "interpolation": interpolation,
                     "pairs": np.array(self.pairs, dtype=int), "D": self.D,
                     "a": np.array(a), "b": np.array(b), "p": np.array(p)}
        return result

    def independent_dual(self, a, b, p):
        """Independently assemble the dual and solve with Clarabel."""
        matrices = self.matrices(a, b)
        c = np.array([0.0, 0.0, p, 0.0, 1.0 - p])
        self.Mflat.value = matrices.reshape(30, 36)
        self.c.value = c
        lam, Z, problem = self.dual_lambda, self.dual_Z, self.dual_problem
        begin = time.perf_counter()
        with warnings.catch_warnings(record=True) as warning_list:
            warnings.simplefilter("always")
            value = problem.solve(solver="CLARABEL", tol_gap_abs=1e-10,
                                  tol_gap_rel=1e-10, tol_feas=1e-10, max_iter=300,
                                  warm_start=False)
        return {"a": float(a), "b": float(b), "p": float(p),
                "status": problem.status, "objective": float(value),
                "dual_flow_residual_inf": float(np.max(np.abs(self.D.T @ lam.value + c))),
                "dual_slack_min_eigenvalue": float(np.linalg.eigvalsh(Z.value)[0]),
                "multiplier_min": float(np.min(lam.value)),
                "wall_time_s": time.perf_counter() - begin,
                "warnings": [str(w.message) for w in warning_list]}


def write_csv(path, rows):
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader(); writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path,
                        default=Path(__file__).resolve().parents[1] / "results")
    args = parser.parse_args(); args.output_dir.mkdir(parents=True, exist_ok=True)
    problem = JointTrajectoryPEP()
    coarse = np.linspace(0, 1, 101)
    fine = np.linspace(P_STAR - 0.008, P_STAR + 0.008, 161)
    probabilities = np.unique(np.r_[coarse, fine, P_STAR])
    rows = []
    for index, p in enumerate(probabilities):
        row = problem.solve(A_STAR, B_STAR, float(p), tag="fixed_optimal_steps")
        rows.append(row)
        if p == P_STAR and problem.last is not None:
            np.savez(args.output_dir / "pep_optimal_solution.npz", **problem.last)
        if index % 50 == 0:
            print(f"sweep {index + 1}/{len(probabilities)} p={p:.6f} "
                  f"risk={row['objective']:.10f} {row['status']}", flush=True)
    write_csv(args.output_dir / "pep_probability_sweep.csv", rows)
    selected = [0.0, 0.5, P_STAR, 1.0]
    checks = []
    for p in selected:
        checks.append(problem.solve(A_STAR, B_STAR, p, tag="clarabel_selected"))
        checks.append(problem.solve(A_STAR, B_STAR, p, tag="clarabel_tolerance_1e-8", tolerance=1e-8))
        checks.append(problem.solve(A_STAR, B_STAR, p, solver="SCS", tag="scs_crosscheck"))
    checks.append(problem.solve(7/5, 19/10, 2/3, tag="rational_separation"))
    checks[-1]["reference_value"] = 5/76
    checks.append(problem.solve(A_DET, B_DET, 1.0, tag="deterministic_optimum"))
    checks[-1]["reference_value"] = R_DET
    checks.append(problem.solve(A_STAR, B_STAR, P_STAR, tag="algebraic_optimum"))
    checks[-1]["reference_value"] = TAU_STAR
    write_csv(args.output_dir / "pep_crosschecks.csv", checks)
    dual_rows = [problem.independent_dual(A_STAR, B_STAR, p) for p in probabilities]
    for primal, dual in zip(rows, dual_rows):
        dual["primal_objective"] = primal["objective"]
        dual["difference_from_primal"] = dual["objective"] - primal["objective"]
    write_csv(args.output_dir / "pep_dual_sweep.csv", dual_rows)
    duals = [r for r in dual_rows if r["p"] in selected]
    # This interpolation-assisted root computation estimates where the fixed
    # pair beats the exact deterministic benchmark; it is not a certificate.
    root_rows = []
    def difference(p):
        row = problem.independent_dual(A_STAR, B_STAR, p)
        row["difference_from_deterministic"] = row["objective"] - R_DET
        root_rows.append(row)
        return row["difference_from_deterministic"]
    crossings = []
    for left, right in zip(dual_rows[:-1], dual_rows[1:]):
        if (left["objective"] - R_DET) * (right["objective"] - R_DET) < 0:
            crossings.append(float(brentq(difference, left["p"], right["p"], xtol=1e-6)))
    write_csv(args.output_dir / "pep_probability_crossings.csv", root_rows)
    finite = [r for r in rows if np.isfinite(r["objective"])]
    summary = {
        "description": "Floating-point common-function smooth-convex PEP; six-by-six Gram matrix; all 30 directed interpolation constraints. These numerical diagnostics do not replace the exact certificates in the theory.",
        "versions": {"python": platform.python_version(), "numpy": np.__version__, "cvxpy": cp.__version__},
        "parameters": {"a_star": A_STAR, "b_star": B_STAR, "p_star": P_STAR,
                       "tau_star": TAU_STAR, "deterministic_reference": R_DET},
        "coarse_grid": {"count": 101, "interval": [0, 1]},
        "fine_grid": {"count": 161, "interval": [float(fine[0]), float(fine[-1])]},
        "sweep_count": len(rows),
        "status_counts": {status: sum(r["status"] == status for r in rows) for status in sorted(set(r["status"] for r in rows))},
        "minimum_sampled_row": min(finite, key=lambda r: r["objective"]),
        "maximum_interpolation_violation": max(r["interpolation_violation"] for r in finite),
        "minimum_gram_eigenvalue": min(r["gram_min_eigenvalue"] for r in finite),
        "maximum_abs_primal_dual_gap": max(abs(r["primal_dual_gap"]) for r in finite),
        "minimum_dual_slack_eigenvalue": min(r["dual_slack_min_eigenvalue"] for r in finite),
        "maximum_dual_flow_residual": max(r["dual_flow_residual_inf"] for r in finite),
        "independent_dual_checks": duals,
        "dual_sweep_status_counts": {status: sum(r["status"] == status for r in dual_rows) for status in sorted(set(r["status"] for r in dual_rows))},
        "dual_sweep_maximum_abs_difference_from_primal": max(abs(r["difference_from_primal"]) for r in dual_rows),
        "dual_sweep_maximum_flow_residual": max(r["dual_flow_residual_inf"] for r in dual_rows),
        "dual_sweep_minimum_slack_eigenvalue": min(r["dual_slack_min_eigenvalue"] for r in dual_rows),
        "estimated_probability_crossings_with_deterministic_benchmark": crossings,
        "relative_improvement_over_optimal_deterministic_percent": 100 * (1 - TAU_STAR / R_DET),
    }
    (args.output_dir / "pep_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k not in ["description", "independent_dual_checks"]}, indent=2))
    for row in checks:
        print(row["tag"], row["p"], row["objective"], row["status"], flush=True)


if __name__ == "__main__":
    main()
