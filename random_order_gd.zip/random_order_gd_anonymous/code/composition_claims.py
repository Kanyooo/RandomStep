"""Claim-aligned composition checks for random-order gradient descent.

Run: python code/composition_claims.py [--output-dir results]

For 2, 4, and 5 steps, solve one joint smooth-convex interpolation PEP
containing every trajectory, with common prefixes sharing oracle nodes.
The same objective is fixed before drawing a random schedule. Both the
primal and an independently assembled dual SDP are solved. These are
floating-point diagnostics, not exact proof certificates.

For longer recursive schedules, compare the proved formula with a common
Huber lower witness. These are sharpness/implementation checks, not PEP
solves and not empirical estimates of a supremum. No Monte Carlo is used.
"""
from __future__ import annotations

import argparse
import csv
import json
import platform
import time
import warnings
from pathlib import Path

import cvxpy as cp
import numpy as np

from schedules import (A_RANDOM, B_RANDOM, A_DETERMINISTIC,
                       B_DETERMINISTIC, H_RANDOM, H_DETERMINISTIC, RHO)


TOLERANCE = 1e-10
RESOLUTION_THRESHOLD = 1e-6


def primary_result_resolved(row):
    """Accept a primary result only when both SDP formulations resolve."""
    valid_statuses = ("optimal", "optimal_inaccurate")
    if (row.get("primal_status") not in valid_statuses
            or row.get("independent_dual_status") not in valid_statuses
            or row.get("primal_exception")
            or row.get("independent_dual_exception")):
        return False
    required = ("primal_objective", "multiplier_dual_objective",
                "independent_dual_objective", "maximum_numerical_residual",
                "independent_dual_multiplier_min", "primal_minus_analytic_upper")
    if not all(np.isfinite(row.get(key, np.nan)) for key in required):
        return False
    return bool(row["maximum_numerical_residual"] < RESOLUTION_THRESHOLD
                and max(0.0, -row["independent_dual_multiplier_min"]) < RESOLUTION_THRESHOLD
                and abs(row["primal_minus_analytic_upper"]) < RESOLUTION_THRESHOLD)


def recursive_schedule(depth, choices, kind="random"):
    """A full schedule specified by every leaf order, with no random draw."""
    choices = tuple(choices)
    assert len(choices) == 2 ** depth
    if depth == 0:
        if kind == "deterministic":
            return (float(A_DETERMINISTIC), float(B_DETERMINISTIC))
        pair = (float(A_RANDOM), float(B_RANDOM))
        return pair if choices[0] == 0 else pair[::-1]
    half = len(choices) // 2
    seed_total = H_DETERMINISTIC if kind == "deterministic" else H_RANDOM
    child_total = (seed_total + 1.0) * RHO ** (depth - 1) - 1.0
    bridge = 1.0 + (np.sqrt(2.0) - 1.0) * (child_total + 1.0)
    return (recursive_schedule(depth - 1, choices[:half], kind)
            + (float(bridge),)
            + recursive_schedule(depth - 1, choices[half:], kind))


def complete_recursive_support(depth, kind="random"):
    if kind == "deterministic":
        return [recursive_schedule(depth, [0] * 2 ** depth, kind)], [1.0]
    leaves = 2 ** depth
    sequences = [recursive_schedule(depth, [(k >> i) & 1 for i in range(leaves)])
                 for k in range(2 ** leaves)]
    return sequences, [1.0 / len(sequences)] * len(sequences)


def support_for(horizon, kind):
    if horizon == 2:
        return complete_recursive_support(0, kind)
    if horizon == 5:
        return complete_recursive_support(1, kind)
    if horizon == 4:
        sequences, probabilities = complete_recursive_support(0, kind)
        H = H_DETERMINISTIC if kind == "deterministic" else H_RANDOM
        suffix = (float(np.sqrt(2 * H + 3)), 1.5)
        return [s + suffix for s in sequences], probabilities
    raise ValueError(horizon)


def exact_total(horizon=None, depth=None, kind="random"):
    H = H_DETERMINISTIC if kind == "deterministic" else H_RANDOM
    if horizon == 4:
        return float(H + np.sqrt(2 * H + 3) + 1.5)
    if depth is None:
        depth = {2: 0, 5: 1}[horizon]
    return float((H + 1) * RHO ** depth - 1)


def huber_value(x, delta):
    return 0.5 * x * x if abs(x) <= delta else delta * abs(x) - 0.5 * delta ** 2


def evaluate_huber(sequence, delta):
    x = 1.0
    minimum_affine_margin = x - delta
    for h in sequence:
        g = np.clip(x, -delta, delta)
        x = x - h * g
        minimum_affine_margin = min(minimum_affine_margin, x - delta)
    return float(huber_value(x, delta)), float(minimum_affine_margin), float(x)


class JointTreePEP:
    """Unrestricted-dimension finite interpolation, one function for all leaves."""

    def __init__(self, sequences, probabilities):
        assert len(sequences) == len(probabilities)
        assert abs(sum(probabilities) - 1.0) < 1e-14
        assert all(p >= 0 for p in probabilities)
        self.sequences = [tuple(map(float, seq)) for seq in sequences]
        self.probabilities = list(map(float, probabilities))
        prefixes = {()}
        for seq in self.sequences:
            prefixes.update(seq[:k] for k in range(1, len(seq) + 1))
        prefixes = sorted(prefixes, key=lambda p: (len(p), p))
        self.prefixes = prefixes
        idx = {prefix: i + 1 for i, prefix in enumerate(prefixes)}
        n = len(prefixes)
        self.dimension = n + 1  # x0, then one gradient per oracle node
        D = self.dimension
        E = np.eye(D)
        X = [np.zeros(D)] + [None] * n
        gradients = [np.zeros(D)] + [E[k] for k in range(1, n + 1)]
        X[idx[()]] = E[0]
        for prefix in prefixes[1:]:
            parent = idx[prefix[:-1]]
            X[idx[prefix]] = X[parent] - prefix[-1] * gradients[parent]
        self.pairs = [(i, j) for i in range(n + 1) for j in range(n + 1) if i != j]
        matrices = []
        differences = []
        for i, j in self.pairs:
            dx = X[i] - X[j]
            dg = gradients[i] - gradients[j]
            matrices.append(0.5 * (np.outer(gradients[j], dx)
                                      + np.outer(dx, gradients[j]) + np.outer(dg, dg)))
            diff = np.zeros(n)
            if i:
                diff[i - 1] += 1
            if j:
                diff[j - 1] -= 1
            differences.append(diff)
        self.M = np.asarray(matrices)
        self.Mflat = self.M.reshape(len(matrices), D * D)
        self.D = np.asarray(differences)
        self.c = np.zeros(n)
        for seq, probability in zip(self.sequences, self.probabilities):
            self.c[idx[seq] - 1] += probability
        self.G = cp.Variable((D, D), symmetric=True)
        self.F = cp.Variable(n)
        self.cons = [self.G >> 0, self.G[0, 0] <= 1,
                     self.D @ self.F - self.Mflat @ cp.vec(self.G, order="C") >= 0]
        self.primal = cp.Problem(cp.Maximize(self.c @ self.F), self.cons)
        self.lam = cp.Variable(len(self.pairs), nonneg=True)
        self.tau = cp.Variable(nonneg=True)
        self.E00 = np.zeros((D, D))
        self.E00[0, 0] = 1.0
        self.Z = self.tau * self.E00 + cp.reshape(self.Mflat.T @ self.lam, (D, D), order="C")
        self.dual = cp.Problem(cp.Minimize(self.tau),
                               [self.D.T @ self.lam == -self.c, self.Z >> 0])
        self.last = None

    def solve(self, solver="CLARABEL", solve_independent_dual=True):
        options = ({"tol_gap_abs": TOLERANCE, "tol_gap_rel": TOLERANCE,
                    "tol_feas": TOLERANCE, "max_iter": 300}
                   if solver == "CLARABEL" else
                   {"eps_abs": 2e-8, "eps_rel": 2e-8, "max_iters": 250000})
        result = {"solver": solver, "dimension": self.dimension,
                  "oracle_nodes_excluding_optimum": len(self.prefixes),
                  "interpolation_constraints": len(self.pairs),
                  "outcomes": len(self.sequences), "horizon": len(self.sequences[0]),
                  "exact_expectation": True, "solver_options": json.dumps(options),
                  "maximum_numerical_residual": np.inf}
        start = time.perf_counter()
        with warnings.catch_warnings(record=True) as warning_list:
            warnings.simplefilter("always")
            try:
                objective = self.primal.solve(solver=solver, warm_start=False, **options)
                exception = ""
            except Exception as exc:
                objective, exception = np.nan, repr(exc)
        result.update(primal_objective=float(objective) if objective is not None else np.nan,
                      primal_status=self.primal.status, primal_exception=exception,
                      primal_seconds=time.perf_counter() - start,
                      primal_warnings=" | ".join(str(w.message) for w in warning_list))
        if self.G.value is None or exception:
            return result
        G = np.asarray(self.G.value)
        F = np.asarray(self.F.value)
        lam = np.asarray(self.cons[2].dual_value)
        tau = float(self.cons[1].dual_value)
        Z = tau * self.E00 + np.einsum("k,kij->ij", lam, self.M)
        Z_solver = np.asarray(self.cons[0].dual_value)
        slacks = self.D @ F - np.einsum("kij,ij->k", self.M, G)
        result.update(
            multiplier_dual_objective=tau,
            multiplier_primal_dual_gap=tau - objective,
            interpolation_min=float(slacks.min()),
            gram_min_eigenvalue=float(np.linalg.eigvalsh(G)[0]),
            normalization_violation=float(max(0.0, G[0, 0] - 1)),
            multiplier_min=float(lam.min()),
            dual_slack_min_eigenvalue=float(np.linalg.eigvalsh(Z)[0]),
            dual_flow_residual_inf=float(np.max(np.abs(self.D.T @ lam + self.c))),
            dual_slack_residual_inf=float(np.max(np.abs(Z - Z_solver))),
            interpolation_complementarity=float(lam @ slacks),
            psd_complementarity=float(np.sum(Z * G)),
            primal_iterations=self.primal.solver_stats.num_iters)
        self.last = {"G": G, "F": F, "lambda": lam, "Z": Z,
                     "M": self.M, "flow_matrix": self.D,
                     "objective_coefficients": self.c,
                     "interpolation_slacks": slacks,
                     "sequences": np.asarray(self.sequences),
                     "probabilities": np.asarray(self.probabilities)}
        if solve_independent_dual:
            start = time.perf_counter()
            with warnings.catch_warnings(record=True) as warning_list:
                warnings.simplefilter("always")
                try:
                    value = self.dual.solve(solver=solver, warm_start=False, **options)
                    exception = ""
                except Exception as exc:
                    value, exception = np.nan, repr(exc)
            result.update(independent_dual_objective=float(value) if value is not None else np.nan,
                          independent_dual_status=self.dual.status,
                          independent_dual_exception=exception,
                          independent_dual_seconds=time.perf_counter() - start,
                          independent_dual_warnings=" | ".join(str(w.message) for w in warning_list))
            if self.lam.value is not None and not exception:
                dlam = np.asarray(self.lam.value)
                dZ = np.asarray(self.Z.value)
                result.update(
                    independent_primal_dual_gap=float(value - objective),
                    independent_dual_flow_residual_inf=float(np.max(np.abs(self.D.T @ dlam + self.c))),
                    independent_dual_multiplier_min=float(dlam.min()),
                    independent_dual_slack_min_eigenvalue=float(np.linalg.eigvalsh(dZ)[0]))
                self.last.update(independent_lambda=dlam, independent_Z=dZ,
                                 independent_tau=np.array(value))
        violations = [max(0, -result["interpolation_min"]),
                      max(0, -result["gram_min_eigenvalue"]),
                      result["normalization_violation"],
                      max(0, -result["multiplier_min"]),
                      max(0, -result["dual_slack_min_eigenvalue"]),
                      result["dual_flow_residual_inf"], result["dual_slack_residual_inf"],
                      abs(result["multiplier_primal_dual_gap"])]
        if "independent_primal_dual_gap" in result:
            violations += [abs(result["independent_primal_dual_gap"]),
                           result["independent_dual_flow_residual_inf"],
                           max(0, -result["independent_dual_multiplier_min"]),
                           max(0, -result["independent_dual_slack_min_eigenvalue"])]
        result["maximum_numerical_residual"] = (float(max(violations))
            if all(np.isfinite(v) for v in violations) else np.inf)
        return result


def write_csv(path, rows):
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def long_horizon_checks():
    rows = []
    for depth in range(2, 9):
        horizon = 3 * 2 ** depth - 1
        for kind in ["random", "deterministic"]:
            H = exact_total(depth=depth, kind=kind)
            delta = 1 / (2 * H + 1)
            upper = 1 / (2 * (2 * H + 1))
            if depth == 2 or kind == "deterministic":
                sequences, probabilities = complete_recursive_support(depth, kind)
                mode = "complete_support_huber_evaluation"
                patterns = ["all_outcomes"]
            else:
                count = 2 ** depth
                choices = [[0] * count, [1] * count,
                           [i % 2 for i in range(count)], [(i + 1) % 2 for i in range(count)]]
                sequences = [recursive_schedule(depth, c, kind) for c in choices]
                probabilities = None
                mode = "order_independent_analytic_value_and_four_fixed_checks"
                patterns = ["all_forward", "all_reverse", "alternating", "opposite_alternating"]
            values = [evaluate_huber(s, delta) for s in sequences]
            analytic_huber = delta * (1 - H * delta) - delta ** 2 / 2
            row = {"horizon": horizon, "depth": depth, "kind": kind,
                   "label": "analytic_sharpness_and_implementation_check_not_full_PEP",
                   "evaluation_mode": mode, "evaluated_sequences": len(sequences),
                   "random_support_log2_size": 2 ** depth if kind == "random" else 0,
                   "fixed_patterns": json.dumps(patterns), "total_stepsize": H,
                   "analytic_upper": upper, "common_huber_delta": delta,
                   "common_huber_analytic_lower": analytic_huber,
                   "upper_minus_analytic_lower": upper - analytic_huber,
                   "max_evaluated_error_from_upper": max(abs(v[0] - upper) for v in values),
                   "minimum_affine_margin": min(v[1] for v in values),
                   "maximum_stepsize_sum_error": max(abs(sum(s) - H) for s in sequences),
                   "minimum_stepsize": min(min(s) for s in sequences)}
            if probabilities is not None:
                row["full_support_expected_huber_error"] = float(sum(p * v[0] for p, v in zip(probabilities, values)))
            rows.append(row)
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path,
                        default=Path(__file__).resolve().parents[1] / "results")
    parser.add_argument("--skip-scs", action="store_true")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    primary = []
    crosschecks = []
    for horizon in [2, 4, 5]:
        for kind in ["random", "deterministic"]:
            sequences, probabilities = support_for(horizon, kind)
            H = exact_total(horizon=horizon, kind=kind)
            upper = 1 / (2 * (2 * H + 1))
            delta = 1 / (2 * H + 1)
            witness = [evaluate_huber(s, delta) for s in sequences]
            problem = JointTreePEP(sequences, probabilities)
            row = problem.solve()
            row.update(kind=kind, total_stepsize=H, analytic_upper=upper,
                       common_huber_delta=delta,
                       common_huber_lower=float(sum(p * w[0] for p, w in zip(probabilities, witness))),
                       huber_branch_value_range=float(max(w[0] for w in witness) - min(w[0] for w in witness)),
                       minimum_huber_affine_margin=float(min(w[1] for w in witness)),
                       stepsize_sum_error=max(abs(sum(s) - H) for s in sequences))
            row["primal_minus_analytic_upper"] = row["primal_objective"] - upper
            row["resolved_to_threshold"] = primary_result_resolved(row)
            primary.append(row)
            if problem.last is not None:
                np.savez_compressed(args.output_dir / f"composition_solution_n{horizon}_{kind}.npz", **problem.last)
            write_csv(args.output_dir / "composition_joint_pep.csv", primary)
            print(f"n={horizon} {kind}: primal={row['primal_objective']:.12f} theory={upper:.12f} "
                  f"status={row['primal_status']} residual={row.get('maximum_numerical_residual', np.nan):.2e}", flush=True)
            if not args.skip_scs and kind == "random":
                cross = problem.solve(solver="SCS", solve_independent_dual=False)
                cross.update(kind=kind, analytic_upper=upper,
                             difference_from_clarabel=cross["primal_objective"] - row["primal_objective"])
                crosschecks.append(cross)
                write_csv(args.output_dir / "composition_solver_crosschecks.csv", crosschecks)
                print(f"  SCS: {cross['primal_objective']:.12f} {cross['primal_status']} "
                      f"difference={cross['difference_from_clarabel']:.2e}", flush=True)
    long_rows = long_horizon_checks()
    write_csv(args.output_dir / "composition_long_horizon_huber.csv", long_rows)
    comparisons = []
    for horizon in [2, 4, 5]:
        random, det = [next(r for r in primary if r["horizon"] == horizon and r["kind"] == k)
                       for k in ["random", "deterministic"]]
        comparisons.append({"horizon": horizon, "evaluation": "full_joint_trajectory_PEP",
                            "random_analytic_risk": random["analytic_upper"],
                            "deterministic_analytic_risk": det["analytic_upper"],
                            "exact_risk_ratio": random["analytic_upper"] / det["analytic_upper"],
                            "analytic_gap": det["analytic_upper"] - random["analytic_upper"],
                            "numerical_gap": det["primal_objective"] - random["primal_objective"],
                            "maximum_numerical_residual": max(random["maximum_numerical_residual"], det["maximum_numerical_residual"]),
                            "both_resolved": random["resolved_to_threshold"] and det["resolved_to_threshold"]})
    for depth in range(2, 9):
        random, det = [next(r for r in long_rows if r["depth"] == depth and r["kind"] == k)
                       for k in ["random", "deterministic"]]
        comparisons.append({"horizon": random["horizon"],
                            "evaluation": "analytic_sharpness_and_implementation_check_not_full_PEP",
                            "random_analytic_risk": random["analytic_upper"],
                            "deterministic_analytic_risk": det["analytic_upper"],
                            "exact_risk_ratio": random["analytic_upper"] / det["analytic_upper"],
                            "analytic_gap": det["analytic_upper"] - random["analytic_upper"]})
    write_csv(args.output_dir / "composition_comparisons.csv", comparisons)
    summary = {"scope": "Claims about specified constructed schedules; no all-horizon minimax or optimal-random-history-seed claim.",
               "estimand": "sup of full-support expected terminal error for one common objective fixed before order draws",
               "deterministic_comparator": "same composition rule with optimal deterministic two-step history seed",
               "versions": {"python": platform.python_version(), "numpy": np.__version__, "cvxpy": cp.__version__},
               "primary_pep_count": len(primary), "scs_crosscheck_count": len(crosschecks),
               "resolution_threshold": RESOLUTION_THRESHOLD,
               "all_primary_resolved": all(r["resolved_to_threshold"] for r in primary),
               "max_primary_residual": max(r["maximum_numerical_residual"] for r in primary),
               "max_primary_theory_difference": max(abs(r["primal_minus_analytic_upper"]) for r in primary),
               "max_scs_disagreement": max((abs(r["difference_from_clarabel"]) for r in crosschecks), default=0),
               "recursive_asymptotic_risk_ratio": float((H_DETERMINISTIC + 1) / (H_RANDOM + 1)),
               "max_long_huber_theory_difference": max(r["max_evaluated_error_from_upper"] for r in long_rows),
               "comparisons": comparisons}
    (args.output_dir / "composition_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
