"""Publication plots for the prespecified claim-aligned experiment protocol."""
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter
from matplotlib.patches import Rectangle

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures'
DATA=ROOT/'results'
BLUE='#2764A5';RED='#C34F32';PURPLE='#7656A4';GREEN='#25856D'


def save(fig,name):
    for ext in ['pdf','svg','png']:
        metadata = {'Creator':'Matplotlib','CreationDate':None} if ext=='pdf' else ({'Creator':'Matplotlib','Date':None} if ext=='svg' else {})
        fig.savefig(OUT/f'{name}.{ext}',bbox_inches='tight',dpi=220,facecolor='white',metadata=metadata)
    plt.close(fig)


def main():
    global DATA, OUT
    parser=argparse.ArgumentParser()
    parser.add_argument('--data-dir',type=Path,default=ROOT/'data')
    parser.add_argument('--output-dir',type=Path,default=ROOT/'figures')
    args=parser.parse_args();DATA=args.data_dir;OUT=args.output_dir
    OUT.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
        'axes.spines.top':False,'axes.spines.right':False,'axes.labelsize':10,
        'axes.titlesize':11,'axes.titlelocation':'center','legend.fontsize':8.5,'lines.linewidth':1.8,
        'pdf.fonttype':42,'ps.fonttype':42})
    q=pd.read_csv(DATA/'two_step_probability_curve.csv').sort_values('p')
    baselines=pd.read_csv(DATA/'two_step_baselines.csv').set_index('tag')
    best=baselines.loc['optimal_random']
    rd=1/(2*(1+2*(np.sqrt(2)+(3+np.sqrt(9+8*np.sqrt(2)))/4)))
    tau=0.06568141550097899620
    fig,axes=plt.subplots(1,2,figsize=(10,3.8),gridspec_kw={'width_ratios':[1.2,1]})
    ax=axes[0]
    ax.plot(q.p,q.objective,color=BLUE,label=r'Common objective: $\sup_f\,\mathbb{E}E_f$')
    ax.plot(q.p,q.order_aware_adversary_upper,color=PURPLE,linestyle='--',
            label=r'Separate branch maxima: $\mathbb{E}\sup_f E_f$')
    ax.axhline(rd,color=RED,linestyle=':',label='Optimal deterministic two-step risk')
    ax.scatter([best.p],[best.objective],s=40,color=BLUE,zorder=5)
    ax.annotate(r'$p_\star\approx0.66349$',xy=(best.p,best.objective),xytext=(.52,.073),
        arrowprops={'arrowstyle':'-','color':BLUE},color=BLUE)
    ax.set(xlim=(0,1),ylim=(.063,.112),xlabel='Probability of the forward order',
        ylabel='Worst-case expected objective error',title='(a) Same optimal stepsizes, different order laws')
    ax.legend(frameon=False,loc='upper right',fontsize=7.8);ax.grid(alpha=.14)
    w=pd.read_csv(DATA/'common_witnesses.csv')
    mat=w[['forward','reverse','mixture']].to_numpy()
    mat=np.vstack([mat,mat.max(axis=0)])
    ax=axes[1]
    ax.imshow(mat,cmap='Blues',vmin=0,vmax=.11,aspect='auto')
    for i in range(4):
        for j in range(3):
            ax.text(j,i,f'{mat[i,j]:.5f}',ha='center',va='center',
                    color='white' if mat[i,j]>.072 else '#14242E',
                    fontsize=10,fontweight='bold' if i==3 else 'normal')
    ax.axhline(2.5,color='white',linewidth=3)
    ax.add_patch(Rectangle((1.5,2.5),1,1,fill=False,edgecolor=GREEN,linewidth=2.5))
    ax.set_xticks(range(3),['Forward','Reverse','Mixture (2/3)'])
    ax.set_yticks(range(4),['Upper-clipped','Lower-clipped','Huber','Column maximum'])
    ax.tick_params(length=0)
    ax.set_title('(b) Three prescribed common objectives')
    ax.set_xlabel('Rational stepsizes (7/5, 19/10)')
    fig.tight_layout(w_pad=2.3)
    save(fig,'two_step_claims')

    l=pd.read_csv(DATA/'two_step_landscape.csv')
    s=pd.read_csv(DATA/'two_step_coordinate_slices.csv')
    a=np.sort(l.a.unique());b=np.sort(l.b.unique())
    z=l.pivot(index='b',columns='a',values='objective').reindex(index=b,columns=a).to_numpy()
    fig,axes=plt.subplots(1,2,figsize=(10,3.65))
    zz=np.maximum(1e3*(z-tau),0)
    im=axes[0].contourf(a,b,zz,levels=20,cmap='viridis_r')
    axes[0].scatter([best.a],[best.b],marker='*',s=110,facecolor='white',edgecolor='#111111',zorder=10)
    axes[0].set(xlabel=r'Stepsize $a$',ylabel=r'Stepsize $b$',title=r'(a) Profile risk $\min_p\mathcal{R}(a,b,p)$')
    cb=fig.colorbar(im,ax=axes[0],pad=.025);cb.set_label(r'Excess above $\tau_\star$ ($\times10^{-3}$)')
    ranges={'a':.02,'b':.04,'p':.10}
    labels={'a':r'$a=a_\star+0.02t$','b':r'$b=b_\star+0.04t$','p':r'$p=p_\star+0.10t$'}
    for coord,color in zip(['a','b','p'],[BLUE,GREEN,PURPLE]):
        v=s[s.coordinate==coord].sort_values('delta')
        axes[1].plot(v.delta/ranges[coord],1e3*np.maximum(v.objective-tau,0),
                      color=color,label=labels[coord])
    axes[1].axhline(1e3*(rd-tau),color=RED,linestyle=':',label='Deterministic benchmark gap')
    axes[1].set(xlabel=r'Scaled perturbation $t$',ylabel=r'Excess risk ($\times10^{-3}$)',
                xlim=(-1,1),title='(b) Coordinate perturbations; others fixed')
    axes[1].grid(alpha=.14);axes[1].legend(frameon=False,fontsize=8)
    fig.tight_layout(w_pad=2)
    save(fig,'parameter_design')

    c=pd.read_csv(DATA/'composition_comparisons.csv').sort_values('horizon')
    tree=pd.read_csv(DATA/'composition_joint_pep.csv')
    rec=c[c.horizon!=4]
    fig,axes=plt.subplots(1,2,figsize=(10,3.65))
    for kind,color in [('random',BLUE),('deterministic',RED)]:
        column=kind+'_analytic_risk'
        axes[0].loglog(rec.horizon,rec[column],color=color,
            linestyle='-' if kind=='random' else '--',label='Exact '+kind+' construction risk')
        axes[0].scatter(rec.horizon,rec[column],s=18,facecolors='none',edgecolors=color,zorder=4,
            label='Huber evaluations' if kind=='random' else None)
        v=tree[tree.kind==kind]
        axes[0].scatter(v.horizon,v.primal_objective,s=43,marker='x',color='#222222',
                         label='Joint-tree PEP (2, 4, 5 steps)' if kind=='random' else None,zorder=6)
    axes[0].set(xlabel='Number of gradient updates',ylabel='Worst-case expected objective error',
                title='(a) Exact bounds, Huber witnesses, and small-tree PEP')
    axes[0].legend(frameon=False,fontsize=7.5);axes[0].grid(alpha=.14)
    axes[1].semilogx(rec.horizon,rec.exact_risk_ratio,'o-',color=BLUE,markersize=4,
                     label='Balanced recursion: exact risk ratio')
    four=c[c.horizon==4].iloc[0]
    axes[1].scatter([4],[four.exact_risk_ratio],marker='D',s=38,color=GREEN,label='Four-step terminal append',zorder=5)
    asym=(1+(np.sqrt(2)+np.sqrt(10+8*np.sqrt(2)))/2)/(101/25)
    axes[1].axhline(asym,color=PURPLE,linestyle='--',label='Asymptotic ratio')
    axes[1].set(xlabel='Number of gradient updates',ylabel='Random / matched deterministic risk',
                ylim=(.9928,.9963),title='(b) Improvement under the same composition rules')
    axes[1].legend(frameon=False,fontsize=7.8);axes[1].grid(alpha=.14)
    for ax in axes:
        ax.set_xticks([2,4,11,47,191,767]);ax.xaxis.set_major_formatter(ScalarFormatter())
    fig.tight_layout(w_pad=2)
    save(fig,'composition_claims')
    print('Saved three claim-aligned figure sets (PDF/SVG/PNG).')


if __name__=='__main__':main()
