"""Exact cross-evaluation on the three analytic witnesses fixed by the theory.

The finite column maxima are witness lower bounds, not automatically full
smooth-convex worst-case risks. All orders see exactly the same objective.
"""
from fractions import Fraction as Q
from pathlib import Path
import argparse
import csv,json

ROOT=Path(__file__).resolve().parents[1]


def upper_value(x):
    c=Q(5,12)
    return x*x/2 if x<=c else c*x-c*c/2


def upper_grad(x):
    return min(x,Q(5,12))


def lower_value(x):
    d=Q(9,38)
    return x*x/2 if x>=-d else -d*x-d*d/2


def lower_grad(x):
    return max(x,-Q(9,38))


def huber_value(x):
    d=Q(5,38)
    return x*x/2 if abs(x)<=d else d*abs(x)-d*d/2


def huber_grad(x):
    return max(-Q(5,38),min(x,Q(5,38)))


def evaluate(gradient,value,steps):
    x=Q(1);trace=[]
    for h in steps:
        g=gradient(x)
        trace.append({'x':str(x),'gradient':str(g),'step':str(h)})
        x-=h*g
    return value(x),trace+[{'x':str(x),'value':str(value(x))}]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir',type=Path,default=ROOT/'results')
    out=parser.parse_args().output_dir
    out.mkdir(parents=True,exist_ok=True)
    a,b,p=Q(7,5),Q(19,10),Q(2,3)
    witnesses=[('upper_clipped',upper_grad,upper_value),
               ('lower_clipped',lower_grad,lower_value),
               ('common_huber',huber_grad,huber_value)]
    rows=[];traces={}
    for name,gradient,value in witnesses:
        forward,ft=evaluate(gradient,value,[a,b])
        reverse,rt=evaluate(gradient,value,[b,a])
        mixture=p*forward+(1-p)*reverse
        fair=(forward+reverse)/2
        rows.append({'instance':name,'forward_exact':str(forward),
            'reverse_exact':str(reverse),'mixture_exact':str(mixture),
            'fair_exact':str(fair),'forward':float(forward),'reverse':float(reverse),
            'mixture':float(mixture),'fair':float(fair)})
        traces[name]={'forward':ft,'reverse':rt}
    # Independent exact expected values from the analytic manuscript examples.
    expected=[(Q(9,128),Q(1,288),Q(83,1728)),
              (Q(1,800),Q(81,760),Q(829,22800)),
              (Q(5,76),Q(5,76),Q(5,76))]
    for row,values in zip(rows,expected):
        for key,val in zip(['forward_exact','reverse_exact','mixture_exact'],values):
            assert Q(row[key])==val
    maxima={name:max(Q(r[name+'_exact']) for r in rows)
            for name in ['forward','reverse','mixture','fair']}
    summary={'steps':['7/5','19/10'],'probability_forward':'2/3',
        'scope':'Finite fixed witness set: column maxima are lower bounds on full-class risk. Full mixture risk5/76 follows from the independent upper certificate.',
        'column_maxima_exact':{k:str(v) for k,v in maxima.items()},
        'column_maxima':{k:float(v) for k,v in maxima.items()},
        'independently_maximized_branch_mixture':float(p*maxima['forward']+(1-p)*maxima['reverse']),
        'common_objective_mixture_on_witness_set':float(maxima['mixture']),
        'all_fraction_checks_pass':True}
    with (out/'common_witnesses.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (out/'common_witnesses.json').write_text(json.dumps({'rows':rows,'traces':traces,'summary':summary},indent=2))
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
