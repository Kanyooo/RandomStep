"""Normalized stepsizes used in the prespecified numerical comparisons.

Each horizon is constructed separately. Random draws choose the order inside
each two-step leaf independently; bridge steps are deterministic.
"""
import numpy as np

A_RANDOM = 273.0 / 200.0
B_RANDOM = 67.0 / 40.0
H_RANDOM = 76.0 / 25.0
H_DETERMINISTIC = (np.sqrt(2.0) + np.sqrt(10.0 + 8.0*np.sqrt(2.0))) / 2.0
A_DETERMINISTIC = np.sqrt(2.0)
B_DETERMINISTIC = H_DETERMINISTIC - A_DETERMINISTIC
A_OPT = 1.39914812843717023214
B_OPT = 1.90722760716161662160
P_OPT = 0.66349447395849179421
TAU_OPT = 0.06568141550097899620
RHO = 1.0 + np.sqrt(2.0)


def _leaf(repetitions, rng, kind):
    if kind == 'deterministic':
        return np.tile([A_DETERMINISTIC, B_DETERMINISTIC], (repetitions, 1))
    if kind == 'random':
        forward = rng.random(repetitions) < 0.5
    elif kind == 'forward':
        forward = np.ones(repetitions, dtype=bool)
    elif kind == 'reverse':
        forward = np.zeros(repetitions, dtype=bool)
    else:
        raise ValueError(kind)
    out = np.empty((repetitions, 2))
    out[:, 0] = np.where(forward, A_RANDOM, B_RANDOM)
    out[:, 1] = np.where(forward, B_RANDOM, A_RANDOM)
    return out


def schedule_matrix(depth, repetitions, rng, kind='random'):
    if depth < 0 or int(depth) != depth:
        raise ValueError('depth must be a nonnegative integer')
    if depth == 0:
        return _leaf(repetitions, rng, kind)
    left = schedule_matrix(depth-1, repetitions, rng, kind)
    right = schedule_matrix(depth-1, repetitions, rng, kind)
    seed_total = H_DETERMINISTIC if kind == 'deterministic' else H_RANDOM
    previous_total = (seed_total+1.0)*RHO**(depth-1)-1.0
    bridge = 1.0+(np.sqrt(2.0)-1.0)*(previous_total+1.0)
    return np.concatenate([left, np.full((repetitions, 1), bridge), right], axis=1)


def four_step_matrix(repetitions, rng, kind='random'):
    seed_total = H_DETERMINISTIC if kind == 'deterministic' else H_RANDOM
    return np.concatenate([_leaf(repetitions, rng, kind),
        np.full((repetitions, 1), np.sqrt(2.0*seed_total+3.0)),
        np.full((repetitions, 1), 1.5)], axis=1)


def stepsize_total(depth, kind='random'):
    h0 = H_DETERMINISTIC if kind == 'deterministic' else H_RANDOM
    return (h0+1.0)*RHO**depth-1.0


def exact_risk(depth=None, kind='random', four_step=False):
    if kind not in ('random', 'deterministic'):
        raise ValueError('Exact risk formula is certified only for random and deterministic history constructions')
    h0 = H_DETERMINISTIC if kind == 'deterministic' else H_RANDOM
    total = h0+np.sqrt(2*h0+3)+1.5 if four_step else stepsize_total(depth, kind)
    return 1.0/(2.0*(2.0*total+1.0))


def validate():
    rng = np.random.default_rng(20260929)
    checks = []
    for kind in ['random', 'deterministic', 'forward', 'reverse']:
        for depth in range(7):
            steps = schedule_matrix(depth, 64, rng, kind)
            expected = stepsize_total(depth, kind)
            error = float(np.max(np.abs(steps.sum(axis=1)-expected)))
            assert steps.shape == (64, 3*2**depth-1)
            assert np.all(steps >= 0)
            assert error < 1e-10
            checks.append({'kind':kind, 'depth':depth, 'sum_error':error})
    assert abs(exact_risk(depth=0)-1/(2*(2*H_RANDOM+1))) < 1e-15
    return checks


if __name__ == '__main__':
    import json
    print(json.dumps(validate(), indent=2))
