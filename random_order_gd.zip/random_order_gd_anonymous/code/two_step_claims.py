"""Two-step common-objective PEP experiments.

The design is described in ../PROTOCOL.md. Every scalar search evaluation, including
failed or inaccurate solves, is retained. Numerical searches are consistency
checks, not proofs of global optimality. Run with BLAS threads set to one.
"""
from __future__ import annotations

import argparse
import json
import platform
import time
import warnings
from pathlib import Path

import cvxpy as cp
import numpy as np
from scipy.optimize import minimize_scalar

from pep_experiment import (JointTrajectoryPEP, A_STAR, B_STAR, P_STAR,
                            TAU_STAR, A_DET, B_DET, R_DET, write_csv)


class Evaluator:
    def __init__(self):
        self.pep = JointTrajectoryPEP()
        self.rows = []
        self.failures = []

    def evaluate(self, a, b, p, tag, tolerance=1e-10):
        pep = self.pep
        matrices = pep.matrices(a, b)
        pep.Mflat.value = matrices.reshape(30, 36)
        pep.c.value = np.array([0., 0., p, 0., 1.-p])
        begin = time.perf_counter()
        with warnings.catch_warnings(record=True) as ws:
            warnings.simplefilter('always')
            try:
                value = pep.dual_problem.solve(
                    solver='CLARABEL', tol_gap_abs=tolerance,
                    tol_gap_rel=tolerance, tol_feas=tolerance,
                    max_iter=300, warm_start=False)
                exception = ''
            except Exception as exc:
                value, exception = np.nan, repr(exc)
        row = dict(evaluation_id=len(self.rows), tag=tag, a=float(a), b=float(b),
                   p=float(p), objective=float(value) if value is not None else np.nan,
                   solver='CLARABEL_explicit_dual', status=pep.dual_problem.status,
                   requested_tolerance=tolerance, exception=exception,
                   warnings=' | '.join(str(w.message) for w in ws),
                   wall_time_s=time.perf_counter()-begin)
        if not exception and pep.dual_lambda.value is not None:
            lam = np.asarray(pep.dual_lambda.value)
            Z = np.asarray(pep.dual_Z.value)
            G = np.asarray(pep.dual_problem.constraints[1].dual_value)
            F = np.asarray(pep.dual_problem.constraints[0].dual_value)
            interpolation = pep.D@F - np.einsum('kij,ij->k', matrices, G)
            primal = float(pep.c.value@F)
            row.update(
                primal_objective=primal,
                primal_dual_gap=float(value)-primal,
                interpolation_min=float(interpolation.min()),
                interpolation_violation=float(max(0., -interpolation.min())),
                gram_min_eigenvalue=float(np.linalg.eigvalsh(G)[0]),
                normalization_violation=float(max(0., G[0,0]-1)),
                multiplier_min=float(lam.min()),
                dual_slack_min_eigenvalue=float(np.linalg.eigvalsh(Z)[0]),
                dual_flow_residual_inf=float(np.max(np.abs(pep.D.T@lam+pep.c.value))),
                interpolation_complementarity=float(lam@interpolation),
                psd_complementarity=float(np.sum(Z*G)),
                iterations=pep.dual_problem.solver_stats.num_iters)
            row['max_validation_error'] = max(
                abs(row['primal_dual_gap']), row['interpolation_violation'],
                max(0., -row['gram_min_eigenvalue']), row['normalization_violation'],
                max(0., -row['multiplier_min']),
                max(0., -row['dual_slack_min_eigenvalue']),
                row['dual_flow_residual_inf'])
            row['resolved'] = bool(np.isfinite(value) and
                pep.dual_problem.status in ('optimal', 'optimal_inaccurate') and
                row['max_validation_error'] < 1e-6)
        else:
            row.update(max_validation_error=np.nan, resolved=False)
        self.rows.append(row)
        if not row['resolved']:
            self.failures.append(row)
        return row

    def optimize_probability(self, a, b, tag, add_candidate=False):
        local = []
        def objective(p):
            row = self.evaluate(a,b,p,tag)
            local.append(row)
            return (row['objective'] if row['resolved'] and
                    np.isfinite(row['objective']) else np.inf)
        result = minimize_scalar(objective, bounds=(0.,1.), method='bounded',
                                 options={'xatol':2e-5, 'maxiter':80})
        for p in [0.,1.] + ([P_STAR] if add_candidate else []):
            objective(p)
        finite = [r for r in local if r['resolved'] and
                  np.isfinite(r['objective'])]
        if not finite:
            return dict(tag=tag,a=a,b=b,p=np.nan,objective=np.nan,resolved=False,
                        search_success=bool(result.success),search_count=len(local))
        best = min(finite,key=lambda r:r['objective']).copy()
        best.update(search_success=bool(result.success),search_count=len(local),
                    search_all_evaluations_resolved=all(r['resolved'] for r in local))
        return best


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output-dir',type=Path,
                        default=Path(__file__).resolve().parents[1]/'results')
    args=parser.parse_args(); out=args.output_dir; out.mkdir(parents=True,exist_ok=True)
    ev=Evaluator(); begin=time.time()
    configurations=[
        ('optimal_random',A_STAR,B_STAR,P_STAR,TAU_STAR),
        ('rational_separation',7/5,19/10,2/3,5/76),
        ('optimal_pair_fair',A_STAR,B_STAR,.5,None),
        ('optimal_pair_forward',A_STAR,B_STAR,1.,None),
        ('optimal_pair_reverse',A_STAR,B_STAR,0.,None),
        ('globally_optimal_deterministic',A_DET,B_DET,1.,R_DET)]
    baselines=[]
    for tag,a,b,p,ref in configurations:
        row=ev.evaluate(a,b,p,tag).copy();row['reference_value']=ref
        if ref is not None: row['difference_from_reference']=row['objective']-ref
        baselines.append(row)
    optimized_det=ev.optimize_probability(A_DET,B_DET,'fixed_deterministic_pair_optimize_p')
    baselines.append(optimized_det)
    write_csv(out/'two_step_baselines.csv',baselines)
    print('baselines',[(r['tag'],r['objective'],r['p']) for r in baselines],flush=True)

    # Full probability curve and mechanism on the exact optimal pair.
    probabilities=np.unique(np.r_[np.linspace(0,1,101),
        np.linspace(P_STAR-.008,P_STAR+.008,161),P_STAR])
    curve=[]
    forward=baselines[3]['objective']; reverse=baselines[4]['objective']
    for p in probabilities:
        row=ev.evaluate(A_STAR,B_STAR,float(p),'optimal_pair_probability_curve').copy()
        row['order_aware_adversary_upper']=p*forward+(1-p)*reverse
        row['difference_from_deterministic']=row['objective']-R_DET
        curve.append(row)
    write_csv(out/'two_step_probability_curve.csv',curve)
    print(f'probability curve complete ({len(curve)} points)',flush=True)

    # Fixed 21 x 21 landscape; the algebraic center is included exactly.
    a_grid=A_STAR+np.linspace(-.04,.04,21)
    b_grid=B_STAR+np.linspace(-.08,.08,21)
    landscape=[]
    for ia,a in enumerate(a_grid):
        for ib,b in enumerate(b_grid):
            row=ev.optimize_probability(float(a),float(b),
                f'landscape_{ia:02d}_{ib:02d}',add_candidate=ia==10 and ib==10)
            row.update(a_index=ia,b_index=ib)
            landscape.append(row)
        write_csv(out/'two_step_landscape.csv',landscape)
        write_csv(out/'two_step_all_evaluations.csv',ev.rows)
        print(f'landscape row {ia+1}/21 elapsed={time.time()-begin:.1f}s',flush=True)
    slices=[]
    for coordinate,width in [('a',.02),('b',.04),('p',.10)]:
        for delta in np.linspace(-width,width,81):
            a,b,p=A_STAR,B_STAR,P_STAR
            if coordinate=='a': a+=delta
            if coordinate=='b': b+=delta
            if coordinate=='p': p+=delta
            row=ev.evaluate(a,b,p,f'coordinate_slice_{coordinate}').copy()
            row.update(coordinate=coordinate,delta=float(delta),
                       difference_from_optimum=row['objective']-TAU_STAR)
            slices.append(row)
    write_csv(out/'two_step_coordinate_slices.csv',slices)

    # Independent primal assembly at all baseline laws and landscape minimum.
    resolved_grid = [r for r in landscape if r['resolved'] and
                     np.isfinite(r['objective'])]
    if not resolved_grid:
        # Preserve every failed evaluation before declining to report a minimum.
        write_csv(out/'two_step_all_evaluations.csv',ev.rows)
        write_csv(out/'two_step_unresolved_evaluations.csv',ev.failures)
        raise RuntimeError('No resolved finite grid evaluation; raw evaluations were saved.')
    grid_best=min(resolved_grid,key=lambda r:r['objective'])
    crosschecks=[]
    for reference in baselines+[dict(grid_best,tag='landscape_minimum')]:
        row=ev.pep.solve(reference['a'],reference['b'],reference['p'],
                         tag=reference['tag']+'_independent_primal')
        row['explicit_dual_objective']=reference['objective']
        row['difference_explicit_dual_minus_primal']=reference['objective']-row['objective']
        crosschecks.append(row)
    write_csv(out/'two_step_primal_crosschecks.csv',crosschecks)
    write_csv(out/'two_step_all_evaluations.csv',ev.rows)
    write_csv(out/'two_step_unresolved_evaluations.csv',ev.failures)
    opt=baselines[0]
    mechanism=dict(joint_common_objective_risk=opt['objective'],
        order_aware_adversary_upper=P_STAR*forward+(1-P_STAR)*reverse,
        description='Weighted sum of separately maximized branch errors permits an order-aware adversary; it is a different quantity, not the random-order risk.')
    summary=dict(protocol='../PROTOCOL.md',versions=dict(python=platform.python_version(),
        numpy=np.__version__,cvxpy=cp.__version__),
        baseline_rows=baselines,landscape_shape=[21,21],landscape_minimum=grid_best,
        probability_curve_count=len(curve),coordinate_slice_points_per_axis=81,
        total_dual_evaluations=len(ev.rows),unresolved_evaluations=len(ev.failures),
        status_counts={s:sum(r['status']==s for r in ev.rows)
                       for s in sorted(set(str(r['status']) for r in ev.rows))},
        maximum_validation_error=max(r.get('max_validation_error',0.) for r in ev.rows),
        maximum_absolute_independent_primal_discrepancy=max(
            abs(r['difference_explicit_dual_minus_primal']) for r in crosschecks),
        mechanism=mechanism,
        relative_improvement_percent=100*(1-opt['objective']/R_DET),
        fixed_deterministic_pair_best_p=optimized_det['p'],
        fixed_deterministic_pair_minimum_difference=optimized_det['objective']-R_DET,
        wall_time_s=time.time()-begin,
        interpretation='Floating-point PEP numerical consistency evidence only. The parameter grid cannot establish global optimality or uniqueness. Full statuses, residuals and all scalar-search evaluations are retained.')
    (out/'two_step_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    lines=['# Claim-aligned two-step numerical results','',
           'All quantities below are numerical common-objective PEP evaluations, not experimental averages over application instances.','',
           '| Configuration | p | Risk | Max diagnostic error |',
           '|---|---:|---:|---:|']
    for r in baselines:
        lines.append(f"| {r['tag']} | {r['p']:.8f} | {r['objective']:.10f} | {r.get('max_validation_error',float('nan')):.3g} |")
    lines += ['',f"Grid minimum: a={grid_best['a']:.10f}, b={grid_best['b']:.10f}, p={grid_best['p']:.10f}, risk={grid_best['objective']:.10f}.",
              f"Joint risk at optimal law: {mechanism['joint_common_objective_risk']:.10f}; order-aware adversary upper: {mechanism['order_aware_adversary_upper']:.10f}.",
              f"Unresolved evaluations: {len(ev.failures)} / {len(ev.rows)}.",
              f"Maximum residual/gap diagnostic: {summary['maximum_validation_error']:.3g}.",
              f"Maximum independent primal discrepancy: {summary['maximum_absolute_independent_primal_discrepancy']:.3g}.",
              '',summary['interpretation']]
    (out/'two_step_report.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(summary,indent=2),flush=True)


if __name__=='__main__':
    main()
